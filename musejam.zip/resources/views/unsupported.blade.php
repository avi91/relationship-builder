<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Unsupported browser</title>
  </head>
  <body>
    <h2>unsupported Browser! Upgrade to access. </h2>
  </body>
</html>
